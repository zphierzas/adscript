﻿$fileName = (Get-Date).tostring("dd-MM-yyyy-hh-mm-ss")
$date = (Get-Date).tostring("dd-MM-yyyy hh:mm tt")
$hostname = hostname

###Sync cmd
aws s3 sync 'D:\Test-NNG\New folder' s3://testnng/NNG1/ > D:\Test-NNG\NNG1-$fileName.log
aws s3 sync 'D:\Test-NNG\New folder (2)' s3://testnng/NNG2/ > D:\Test-NNG\NNG2-$fileName.log

###report
$overall = aws s3 ls s3://nh-nng-backup/ --recursive --human-readable  --summarize | Select-String "Total "
$onlyresult = aws s3 ls s3://nh-nng-backup/NIPT_Labresult/ --recursive --human-readable  --summarize | Select-String "Total "
$onlynng = aws s3 ls s3://nh-nng-backup/NNG/ --recursive --human-readable  --summarize | Select-String "Total "
$intro = echo ("NNG-Sync Report. Project: NAS-NNG Backup")
$upload1 = (get-content D:\Test-NNG\NNG1-$fileName.log | select-string -pattern "upload: ").length
$upload2 = (get-content D:\Test-NNG\NNG2-$fileName.log | select-string -pattern "upload: ").length
$sum = @($upload1,$upload2)
$total = ($sum |Measure-Object -sum ).sum
$uptxt = echo ("NNG-NAS sync completed on: "+$date+"`n`n"+"Upload: "+$upload1+" objects from folder NIPT_Labresult/`nUpload: "+$upload2+" objects from folder NNG/"+"`nTotal Upload: "+$total+" objects`n")
$txt1 = echo ("--------------------------------------------------`n"+"--------------------------------------------------`n"+"----------------AWS S3 report---------------------`n"+"--------------------------------------------------`n"+"--------------------------------------------------`n"+"Object in bucket: nh-nng-backup/`n"+$overall+"`n"+"--------------------------------------------------")
$txt2 = echo ("NIPT_Labresult/`n"+$onlyresult+"`n"+"--------------------------------------------------")
$txt3 = echo ("NNG/`n"+$onlynng+"`n"+"--------------------------------------------------`n"+"--------------------------------------------------`n")
$endtxt = echo ("Report generated from $hostname`n"+"Script by AdminModern@DE-Nhealth")
echo $intro $uptxt $txt1 $txt2 $txt3 $endtxt > D:\$fileName.log

###Send notification to email
#$path = "D:\$filename.log" 
#$groups = Get-Content $path -Raw
#Send-MailMessage -SmtpServer smtp25.bdms.co.th -Port 25 -From nas-nng@nhhealth-asia.com -To n-health-infrastructure-group@nhealth-asia.com -Subject "NNG-S3-Sync-result" -Body  "$groups"

###Delete buffer file
#del D:\$filename.log
del D:\Test-NNG\NNG1-$fileName.log
del D:\Test-NNG\NNG2-$fileName.log