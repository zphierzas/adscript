﻿# Import active directory module for running AD cmdlets
Import-Module ActiveDirectory
  
# Store the data from NewUsersFinal.csv in the $ADUsers variable
$ADUsers = Import-Csv C:\Users\Patcharapong.Ne\Desktop\ADpowershell\CreateNewUser\NewUsersFin.csv -Delimiter ","

# Define UPN
$UPN = "BDMS.CO.TH"

# Loop through each row containing user details in the CSV file
foreach ($User in $ADUsers) {

    #Read user data from each field in each row and assign the data to a variable as below
    $username = $User.username
    $password = $User.password
    $firstname = $User.firstname
    $lastname = $User.lastname
    $OU = "OU=User,OU=Internet Security,OU=NHealth,OU=Locations,DC=BDMS,DC=CO,DC=TH"
    $jobtitle = $User.jobtitle
    $office = "N Health"
    $company = "N Health"
    $department = $User.department
    $description = $user.description

    # Check to see if the user already exists in AD
    if (Get-ADUser -F { SamAccountName -eq $username }) {
        
        # If user does exist, give a warning
        Write-Warning "A user account with username $username already exists in Active Directory."
    }
    else {

        # User does not exist then proceed to create the new user account
        # Account will be created in the OU provided by the $OU variable read from the CSV file
        New-ADUser `
            -SamAccountName $username `
            -UserPrincipalName "$username@$UPN" `
            -Name "$firstname $lastname" `
            -GivenName $firstname `
            -Surname $lastname `
            -Enabled $True `
            -DisplayName "$firstname $lastname" `
            -Path $OU `
            -Company $company `
            -Office $office `
            -Title $jobtitle `
            -Description $description `
            -Department $department `
            -AccountPassword (ConvertTo-secureString $password -AsPlainText -Force) -ChangePasswordAtLogon $false -PasswordNeverExpires $true  -CannotChangePassword $true

        # If user is created, show message.
        Write-Host "The user account $username is created." -ForegroundColor green
    }
}

Read-Host -Prompt "Press Enter to exit"